import React from "react";

const Imag = () => {
  return (
    <img src={"/imagen1.jpg"} alt="" className="absolute top-0 dog-2 w-1/2" />
  );
};

export default Imag;
